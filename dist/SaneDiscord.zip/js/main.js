/**
 * SaneDiscord - return to old discord emotes
 */

alert('alyoo');
